package mx.tec.arredondovalle_ep2.dao

import androidx.room.Query
import androidx.room.Dao
import androidx.room.Insert
import mx.tec.arredondovalle_ep2.model.Reminder

@Dao
interface ReminderDao {
    @Query("SELECT * FROM Reminder")
    fun getAll(): List<Reminder>
    @Insert
    fun registrarReminder(reminder: Reminder)
}