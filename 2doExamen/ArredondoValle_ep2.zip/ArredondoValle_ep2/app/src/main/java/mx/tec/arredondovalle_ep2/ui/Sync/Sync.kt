package mx.tec.arredondovalle_ep2.ui.Sync;

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.util.Log
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import mx.tec.arredondovalle_ep2.R
import mx.tec.arredondovalle_ep2.model.Reminder
import mx.tec.arredondovalle_ep2.utility.AppDatabase
import org.json.JSONArray
import org.json.JSONException

class Sync : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val view: View = inflater.inflate(R.layout.fragment_sync, container, false)
        val db = AppDatabase.getInstance(requireContext())
        val queue = Volley.newRequestQueue(requireContext())
        val remoteUrl =
            "https://laventana-env-1.eba-4xgdujcc.us-east-1.elasticbeanstalk.com/recordatorios"

        // Define a method for synchronizing data
        val syncData = {
            val stringRequest = StringRequest(
                Request.Method.GET, remoteUrl,
                { response ->
                    // Log the response here
                    Log.d("RESPONSE", "Response: $response")
                    try {
                        val list = parseResponse(response)
                        for (item in list) {
                            db.ReminderDao().registrarReminder(item)
                        }
                    } catch (e: Exception) {
                        Log.e("ERROR", "Error processing response: ${e.message}")
                    }
                },
                { error ->
                    Log.e("ERROR", "Error in the request: ${error.message}")
                }
            )
            queue.add(stringRequest)
        }

        val syncButton = view.findViewById<View>(R.id.btnSync2)
        syncButton.setOnClickListener {
            syncData()
        }

        return view
    }

    private fun parseResponse(response: String): List<Reminder> {
        val list = mutableListOf<Reminder>()

        try {
            val jsonArray = JSONArray(response)
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val id = jsonObject.getInt("idReminder")
                val title = jsonObject.getString("title")
                val description = jsonObject.getString("description")
                val category = jsonObject.getString("category")

                val reminder = Reminder(id, title, description, category)
                list.add(reminder)
            }
        } catch (e: JSONException) {
            Log.e("JSON Parsing Error", "Error parsing JSON: ${e.message}")
        }

        return list
    }
}
